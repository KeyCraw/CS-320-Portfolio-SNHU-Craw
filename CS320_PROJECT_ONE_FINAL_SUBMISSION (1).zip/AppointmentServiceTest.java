
/**
 * JUnit tests for AppointmentService class.
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAndDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("A1", futureDate, "Meeting");

        service.addAppointment(appointment);
        service.deleteAppointment("A1");

        assertTrue(true);
    }

    @Test
    public void testDuplicateIdNotAllowed() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment a1 = new Appointment("A1", futureDate, "Meeting");
        Appointment a2 = new Appointment("A1", futureDate, "Another");

        service.addAppointment(a1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(a2);
        });
    }
}
