
/**
 * JUnit tests for Appointment class.
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("123", futureDate, "Doctor Visit");
        assertEquals("123", appointment.getAppointmentId());
    }

    @Test
    public void testPastDateNotAllowed() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Invalid");
        });
    }
}
