import java.util.HashMap;
import java.util.Map;

/**
 * TaskService class manages tasks in memory using a HashMap.
 * Supports adding, deleting, and updating tasks by task ID.
 */
public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a task to the service
     *
     * @param task Task object to add
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task by task ID
     *
     * @param taskId ID of task to delete
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of a task
     *
     * @param taskId ID of the task
     * @param name   new name
     */
    public void updateName(String taskId, String name) {
        getTask(taskId).setName(name);
    }

    /**
     * Updates the description of a task
     *
     * @param taskId      ID of the task
     * @param description new description
     */
    public void updateDescription(String taskId, String description) {
        getTask(taskId).setDescription(description);
    }

    private Task getTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        return tasks.get(taskId);
    }
}