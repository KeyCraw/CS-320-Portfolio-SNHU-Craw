import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for Task class to verify all field validation rules.
 */
public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("1", "Homework", "Complete CS assignment");
        assertEquals("1", task.getTaskId());
    }

    @Test
    void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Homework", "Complete CS assignment"));
    }

    @Test
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", null, "Complete CS assignment"));
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", "Homework", null));
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", "ThisNameIsWayTooLongToBeValid", "Desc"));
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", "Homework", "This description is way too long to be valid in the system"));
    }
}