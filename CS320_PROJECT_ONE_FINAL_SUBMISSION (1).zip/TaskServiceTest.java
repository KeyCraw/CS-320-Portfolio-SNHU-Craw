import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for TaskService to verify all CRUD operations.
 */
public class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Homework", "Complete CS assignment");
        service.addTask(task);
    }

    @Test
    void testAddDuplicateTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Homework", "Complete CS assignment");
        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Homework", "Complete CS assignment");
        service.addTask(task);
        service.deleteTask("1");
    }

    @Test
    void testUpdateTaskFields() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Homework", "Complete CS assignment");
        service.addTask(task);

        service.updateName("1", "Project");
        service.updateDescription("1", "Complete Module Four Milestone");

        assertEquals("Project", task.getName());
        assertEquals("Complete Module Four Milestone", task.getDescription());
    }
}