/**
 * Task class represents a task object with a unique ID, name, and description.
 * All fields are validated according to the project requirements.
 */
public class Task {

    private final String taskId; // not updatable
    private String name;
    private String description;

    /**
     * Constructor to create a new Task object
     *
     * @param taskId      unique task ID (max 10 chars, not null)
     * @param name        task name (max 20 chars, not null)
     * @param description task description (max 50 chars, not null)
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
}